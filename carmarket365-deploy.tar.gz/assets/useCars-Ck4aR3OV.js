import{c as _,a as te,b as ne,ad as Q}from"./radix-vendor-w4WxdnC1.js";import{H as se,J as Ee,T as re,K as R,M as ie,N as ve,O as xe,P as ae,Q as M,R as c,U as S,V as Ne,W as Te,X as ge,Y as Ae,Z as q,_ as Ie,$ as A,a0 as ke,a1 as Ce,a2 as be,h as oe}from"./index-D_PxUy_v.js";import{r as N,R as _e}from"./router-B5cMtwIt.js";function ce(n){const e=N.useContext(se()),t=n||e.client;return Ee(!!t,28),t}function Oe(n){return typeof n=="object"&&n!==null}function Se(n,e){if(!!!n)throw new Error("Unexpected invariant triggered.")}const De=/\r\n|[\n\r]/g;function V(n,e){let t=0,r=1;for(const s of n.body.matchAll(De)){if(typeof s.index=="number"||Se(!1),s.index>=e)break;t=s.index+s[0].length,r+=1}return{line:r,column:e+1-t}}function we(n){return ue(n.source,V(n.source,n.start))}function ue(n,e){const t=n.locationOffset.column-1,r="".padStart(t)+n.body,s=e.line-1,i=n.locationOffset.line-1,o=e.line+i,l=e.line===1?t:0,d=e.column+l,y=`${n.name}:${o}:${d}
`,u=r.split(/\r\n|[\n\r]/g),v=u[s];if(v.length>120){const E=Math.floor(d/80),g=d%80,f=[];for(let x=0;x<v.length;x+=80)f.push(v.slice(x,x+80));return y+z([[`${o} |`,f[0]],...f.slice(1,E+1).map(x=>["|",x]),["|","^".padStart(g)],["|",f[E+1]]])}return y+z([[`${o-1} |`,u[s-1]],[`${o} |`,v],["|","^".padStart(d)],[`${o+1} |`,u[s+1]]])}function z(n){const e=n.filter(([r,s])=>s!==void 0),t=Math.max(...e.map(([r])=>r.length));return e.map(([r,s])=>r.padStart(t)+(s?" "+s:"")).join(`
`)}function Le(n){const e=n[0];return e==null||"kind"in e||"length"in e?{nodes:e,source:n[1],positions:n[2],path:n[3],originalError:n[4],extensions:n[5]}:e}class Y extends Error{constructor(e,...t){var r,s,i;const{nodes:o,source:l,positions:d,path:y,originalError:u,extensions:v}=Le(t);super(e),this.name="GraphQLError",this.path=y??void 0,this.originalError=u??void 0,this.nodes=H(Array.isArray(o)?o:o?[o]:void 0);const E=H((r=this.nodes)===null||r===void 0?void 0:r.map(f=>f.loc).filter(f=>f!=null));this.source=l??(E==null||(s=E[0])===null||s===void 0?void 0:s.source),this.positions=d??E?.map(f=>f.start),this.locations=d&&l?d.map(f=>V(l,f)):E?.map(f=>V(f.source,f.start));const g=Oe(u?.extensions)?u?.extensions:void 0;this.extensions=(i=v??g)!==null&&i!==void 0?i:Object.create(null),Object.defineProperties(this,{message:{writable:!0,enumerable:!0},name:{enumerable:!1},nodes:{enumerable:!1},source:{enumerable:!1},positions:{enumerable:!1},originalError:{enumerable:!1}}),u!=null&&u.stack?Object.defineProperty(this,"stack",{value:u.stack,writable:!0,configurable:!0}):Error.captureStackTrace?Error.captureStackTrace(this,Y):Object.defineProperty(this,"stack",{value:Error().stack,writable:!0,configurable:!0})}get[Symbol.toStringTag](){return"GraphQLError"}toString(){let e=this.message;if(this.nodes)for(const t of this.nodes)t.loc&&(e+=`

`+we(t.loc));else if(this.source&&this.locations)for(const t of this.locations)e+=`

`+ue(this.source,t);return e}toJSON(){const e={message:this.message};return this.locations!=null&&(e.locations=this.locations),this.path!=null&&(e.path=this.path),this.extensions!=null&&Object.keys(this.extensions).length>0&&(e.extensions=this.extensions),e}}function H(n){return n===void 0||n.length===0?void 0:n}function m(n,e,t){return new Y(`Syntax Error: ${t}`,{source:n,positions:[e]})}var G;(function(n){n.QUERY="QUERY",n.MUTATION="MUTATION",n.SUBSCRIPTION="SUBSCRIPTION",n.FIELD="FIELD",n.FRAGMENT_DEFINITION="FRAGMENT_DEFINITION",n.FRAGMENT_SPREAD="FRAGMENT_SPREAD",n.INLINE_FRAGMENT="INLINE_FRAGMENT",n.VARIABLE_DEFINITION="VARIABLE_DEFINITION",n.SCHEMA="SCHEMA",n.SCALAR="SCALAR",n.OBJECT="OBJECT",n.FIELD_DEFINITION="FIELD_DEFINITION",n.ARGUMENT_DEFINITION="ARGUMENT_DEFINITION",n.INTERFACE="INTERFACE",n.UNION="UNION",n.ENUM="ENUM",n.ENUM_VALUE="ENUM_VALUE",n.INPUT_OBJECT="INPUT_OBJECT",n.INPUT_FIELD_DEFINITION="INPUT_FIELD_DEFINITION"})(G||(G={}));var a;(function(n){n.SOF="<SOF>",n.EOF="<EOF>",n.BANG="!",n.DOLLAR="$",n.AMP="&",n.PAREN_L="(",n.PAREN_R=")",n.SPREAD="...",n.COLON=":",n.EQUALS="=",n.AT="@",n.BRACKET_L="[",n.BRACKET_R="]",n.BRACE_L="{",n.PIPE="|",n.BRACE_R="}",n.NAME="Name",n.INT="Int",n.FLOAT="Float",n.STRING="String",n.BLOCK_STRING="BlockString",n.COMMENT="Comment"})(a||(a={}));class Re{constructor(e){const t=new re(a.SOF,0,0,0,0);this.source=e,this.lastToken=t,this.token=t,this.line=1,this.lineStart=0}get[Symbol.toStringTag](){return"Lexer"}advance(){return this.lastToken=this.token,this.token=this.lookahead()}lookahead(){let e=this.token;if(e.kind!==a.EOF)do if(e.next)e=e.next;else{const t=Pe(this,e.end);e.next=t,t.prev=e,e=t}while(e.kind===a.COMMENT);return e}}function Fe(n){return n===a.BANG||n===a.DOLLAR||n===a.AMP||n===a.PAREN_L||n===a.PAREN_R||n===a.SPREAD||n===a.COLON||n===a.EQUALS||n===a.AT||n===a.BRACKET_L||n===a.BRACKET_R||n===a.BRACE_L||n===a.PIPE||n===a.BRACE_R}function I(n){return n>=0&&n<=55295||n>=57344&&n<=1114111}function P(n,e){return le(n.charCodeAt(e))&&de(n.charCodeAt(e+1))}function le(n){return n>=55296&&n<=56319}function de(n){return n>=56320&&n<=57343}function T(n,e){const t=n.source.body.codePointAt(e);if(t===void 0)return a.EOF;if(t>=32&&t<=126){const r=String.fromCodePoint(t);return r==='"'?`'"'`:`"${r}"`}return"U+"+t.toString(16).toUpperCase().padStart(4,"0")}function h(n,e,t,r,s){const i=n.line,o=1+t-n.lineStart;return new re(e,t,r,i,o,s)}function Pe(n,e){const t=n.source.body,r=t.length;let s=e;for(;s<r;){const i=t.charCodeAt(s);switch(i){case 65279:case 9:case 32:case 44:++s;continue;case 10:++s,++n.line,n.lineStart=s;continue;case 13:t.charCodeAt(s+1)===10?s+=2:++s,++n.line,n.lineStart=s;continue;case 35:return Me(n,s);case 33:return h(n,a.BANG,s,s+1);case 36:return h(n,a.DOLLAR,s,s+1);case 38:return h(n,a.AMP,s,s+1);case 40:return h(n,a.PAREN_L,s,s+1);case 41:return h(n,a.PAREN_R,s,s+1);case 46:if(t.charCodeAt(s+1)===46&&t.charCodeAt(s+2)===46)return h(n,a.SPREAD,s,s+3);break;case 58:return h(n,a.COLON,s,s+1);case 61:return h(n,a.EQUALS,s,s+1);case 64:return h(n,a.AT,s,s+1);case 91:return h(n,a.BRACKET_L,s,s+1);case 93:return h(n,a.BRACKET_R,s,s+1);case 123:return h(n,a.BRACE_L,s,s+1);case 124:return h(n,a.PIPE,s,s+1);case 125:return h(n,a.BRACE_R,s,s+1);case 34:return t.charCodeAt(s+1)===34&&t.charCodeAt(s+2)===34?Ke(n,s):Be(n,s)}if(R(i)||i===45)return Ue(n,s,i);if(ie(i))return je(n,s);throw m(n.source,s,i===39?`Unexpected single quote character ('), did you mean to use a double quote (")?`:I(i)||P(t,s)?`Unexpected character: ${T(n,s)}.`:`Invalid character: ${T(n,s)}.`)}return h(n,a.EOF,r,r)}function Me(n,e){const t=n.source.body,r=t.length;let s=e+1;for(;s<r;){const i=t.charCodeAt(s);if(i===10||i===13)break;if(I(i))++s;else if(P(t,s))s+=2;else break}return h(n,a.COMMENT,e,s,t.slice(e+1,s))}function Ue(n,e,t){const r=n.source.body;let s=e,i=t,o=!1;if(i===45&&(i=r.charCodeAt(++s)),i===48){if(i=r.charCodeAt(++s),R(i))throw m(n.source,s,`Invalid number, unexpected digit after 0: ${T(n,s)}.`)}else s=U(n,s,i),i=r.charCodeAt(s);if(i===46&&(o=!0,i=r.charCodeAt(++s),s=U(n,s,i),i=r.charCodeAt(s)),(i===69||i===101)&&(o=!0,i=r.charCodeAt(++s),(i===43||i===45)&&(i=r.charCodeAt(++s)),s=U(n,s,i),i=r.charCodeAt(s)),i===46||ie(i))throw m(n.source,s,`Invalid number, expected digit but got: ${T(n,s)}.`);return h(n,o?a.FLOAT:a.INT,e,s,r.slice(e,s))}function U(n,e,t){if(!R(t))throw m(n.source,e,`Invalid number, expected digit but got: ${T(n,e)}.`);const r=n.source.body;let s=e+1;for(;R(r.charCodeAt(s));)++s;return s}function Be(n,e){const t=n.source.body,r=t.length;let s=e+1,i=s,o="";for(;s<r;){const l=t.charCodeAt(s);if(l===34)return o+=t.slice(i,s),h(n,a.STRING,e,s+1,o);if(l===92){o+=t.slice(i,s);const d=t.charCodeAt(s+1)===117?t.charCodeAt(s+2)===123?$e(n,s):Ve(n,s):Ge(n,s);o+=d.value,s+=d.size,i=s;continue}if(l===10||l===13)break;if(I(l))++s;else if(P(t,s))s+=2;else throw m(n.source,s,`Invalid character within String: ${T(n,s)}.`)}throw m(n.source,s,"Unterminated string.")}function $e(n,e){const t=n.source.body;let r=0,s=3;for(;s<12;){const i=t.charCodeAt(e+s++);if(i===125){if(s<5||!I(r))break;return{value:String.fromCodePoint(r),size:s}}if(r=r<<4|b(i),r<0)break}throw m(n.source,e,`Invalid Unicode escape sequence: "${t.slice(e,e+s)}".`)}function Ve(n,e){const t=n.source.body,r=J(t,e+2);if(I(r))return{value:String.fromCodePoint(r),size:6};if(le(r)&&t.charCodeAt(e+6)===92&&t.charCodeAt(e+7)===117){const s=J(t,e+8);if(de(s))return{value:String.fromCodePoint(r,s),size:12}}throw m(n.source,e,`Invalid Unicode escape sequence: "${t.slice(e,e+6)}".`)}function J(n,e){return b(n.charCodeAt(e))<<12|b(n.charCodeAt(e+1))<<8|b(n.charCodeAt(e+2))<<4|b(n.charCodeAt(e+3))}function b(n){return n>=48&&n<=57?n-48:n>=65&&n<=70?n-55:n>=97&&n<=102?n-87:-1}function Ge(n,e){const t=n.source.body;switch(t.charCodeAt(e+1)){case 34:return{value:'"',size:2};case 92:return{value:"\\",size:2};case 47:return{value:"/",size:2};case 98:return{value:"\b",size:2};case 102:return{value:"\f",size:2};case 110:return{value:`
`,size:2};case 114:return{value:"\r",size:2};case 116:return{value:"	",size:2}}throw m(n.source,e,`Invalid character escape sequence: "${t.slice(e,e+2)}".`)}function Ke(n,e){const t=n.source.body,r=t.length;let s=n.lineStart,i=e+3,o=i,l="";const d=[];for(;i<r;){const y=t.charCodeAt(i);if(y===34&&t.charCodeAt(i+1)===34&&t.charCodeAt(i+2)===34){l+=t.slice(o,i),d.push(l);const u=h(n,a.BLOCK_STRING,e,i+3,ve(d).join(`
`));return n.line+=d.length-1,n.lineStart=s,u}if(y===92&&t.charCodeAt(i+1)===34&&t.charCodeAt(i+2)===34&&t.charCodeAt(i+3)===34){l+=t.slice(o,i),o=i+1,i+=4;continue}if(y===10||y===13){l+=t.slice(o,i),d.push(l),y===13&&t.charCodeAt(i+1)===10?i+=2:++i,l="",o=i,s=i;continue}if(I(y))++i;else if(P(t,i))i+=2;else throw m(n.source,i,`Invalid character within String: ${T(n,i)}.`)}throw m(n.source,i,"Unterminated string.")}function je(n,e){const t=n.source.body,r=t.length;let s=e+1;for(;s<r;){const i=t.charCodeAt(s);if(xe(i))++s;else break}return h(n,a.NAME,e,s,t.slice(e,s))}const qe=globalThis.process&&!0,Ye=qe?function(e,t){return e instanceof t}:function(e,t){if(e instanceof t)return!0;if(typeof e=="object"&&e!==null){var r;const s=t.prototype[Symbol.toStringTag],i=Symbol.toStringTag in e?e[Symbol.toStringTag]:(r=e.constructor)===null||r===void 0?void 0:r.name;if(s===i){const o=ae(e);throw new Error(`Cannot use ${s} "${o}" from another module or realm.

Ensure that there is only one instance of "graphql" in the node_modules
directory. If different versions of "graphql" are the dependencies of other
relied on modules, use "resolutions" to ensure only one version is installed.

https://yarnpkg.com/en/docs/selective-version-resolutions

Duplicate "graphql" modules cannot be used at the same time since different
versions may have different capabilities and behavior. The data from one
version used in the function from another could produce confusing and
spurious results.`)}}return!1};class he{constructor(e,t="GraphQL request",r={line:1,column:1}){typeof e=="string"||M(!1,`Body must be a string. Received: ${ae(e)}.`),this.body=e,this.name=t,this.locationOffset=r,this.locationOffset.line>0||M(!1,"line in locationOffset is 1-indexed and must be positive."),this.locationOffset.column>0||M(!1,"column in locationOffset is 1-indexed and must be positive.")}get[Symbol.toStringTag](){return"Source"}}function Qe(n){return Ye(n,he)}function ze(n,e){const t=new He(n,e),r=t.parseDocument();return Object.defineProperty(r,"tokenCount",{enumerable:!1,value:t.tokenCount}),r}class He{constructor(e,t={}){const r=Qe(e)?e:new he(e);this._lexer=new Re(r),this._options=t,this._tokenCounter=0}get tokenCount(){return this._tokenCounter}parseName(){const e=this.expectToken(a.NAME);return this.node(e,{kind:c.NAME,value:e.value})}parseDocument(){return this.node(this._lexer.token,{kind:c.DOCUMENT,definitions:this.many(a.SOF,this.parseDefinition,a.EOF)})}parseDefinition(){if(this.peek(a.BRACE_L))return this.parseOperationDefinition();const e=this.peekDescription(),t=e?this._lexer.lookahead():this._lexer.token;if(t.kind===a.NAME){switch(t.value){case"schema":return this.parseSchemaDefinition();case"scalar":return this.parseScalarTypeDefinition();case"type":return this.parseObjectTypeDefinition();case"interface":return this.parseInterfaceTypeDefinition();case"union":return this.parseUnionTypeDefinition();case"enum":return this.parseEnumTypeDefinition();case"input":return this.parseInputObjectTypeDefinition();case"directive":return this.parseDirectiveDefinition()}if(e)throw m(this._lexer.source,this._lexer.token.start,"Unexpected description, descriptions are supported only on type definitions.");switch(t.value){case"query":case"mutation":case"subscription":return this.parseOperationDefinition();case"fragment":return this.parseFragmentDefinition();case"extend":return this.parseTypeSystemExtension()}}throw this.unexpected(t)}parseOperationDefinition(){const e=this._lexer.token;if(this.peek(a.BRACE_L))return this.node(e,{kind:c.OPERATION_DEFINITION,operation:S.QUERY,name:void 0,variableDefinitions:[],directives:[],selectionSet:this.parseSelectionSet()});const t=this.parseOperationType();let r;return this.peek(a.NAME)&&(r=this.parseName()),this.node(e,{kind:c.OPERATION_DEFINITION,operation:t,name:r,variableDefinitions:this.parseVariableDefinitions(),directives:this.parseDirectives(!1),selectionSet:this.parseSelectionSet()})}parseOperationType(){const e=this.expectToken(a.NAME);switch(e.value){case"query":return S.QUERY;case"mutation":return S.MUTATION;case"subscription":return S.SUBSCRIPTION}throw this.unexpected(e)}parseVariableDefinitions(){return this.optionalMany(a.PAREN_L,this.parseVariableDefinition,a.PAREN_R)}parseVariableDefinition(){return this.node(this._lexer.token,{kind:c.VARIABLE_DEFINITION,variable:this.parseVariable(),type:(this.expectToken(a.COLON),this.parseTypeReference()),defaultValue:this.expectOptionalToken(a.EQUALS)?this.parseConstValueLiteral():void 0,directives:this.parseConstDirectives()})}parseVariable(){const e=this._lexer.token;return this.expectToken(a.DOLLAR),this.node(e,{kind:c.VARIABLE,name:this.parseName()})}parseSelectionSet(){return this.node(this._lexer.token,{kind:c.SELECTION_SET,selections:this.many(a.BRACE_L,this.parseSelection,a.BRACE_R)})}parseSelection(){return this.peek(a.SPREAD)?this.parseFragment():this.parseField()}parseField(){const e=this._lexer.token,t=this.parseName();let r,s;return this.expectOptionalToken(a.COLON)?(r=t,s=this.parseName()):s=t,this.node(e,{kind:c.FIELD,alias:r,name:s,arguments:this.parseArguments(!1),directives:this.parseDirectives(!1),selectionSet:this.peek(a.BRACE_L)?this.parseSelectionSet():void 0})}parseArguments(e){const t=e?this.parseConstArgument:this.parseArgument;return this.optionalMany(a.PAREN_L,t,a.PAREN_R)}parseArgument(e=!1){const t=this._lexer.token,r=this.parseName();return this.expectToken(a.COLON),this.node(t,{kind:c.ARGUMENT,name:r,value:this.parseValueLiteral(e)})}parseConstArgument(){return this.parseArgument(!0)}parseFragment(){const e=this._lexer.token;this.expectToken(a.SPREAD);const t=this.expectOptionalKeyword("on");return!t&&this.peek(a.NAME)?this.node(e,{kind:c.FRAGMENT_SPREAD,name:this.parseFragmentName(),directives:this.parseDirectives(!1)}):this.node(e,{kind:c.INLINE_FRAGMENT,typeCondition:t?this.parseNamedType():void 0,directives:this.parseDirectives(!1),selectionSet:this.parseSelectionSet()})}parseFragmentDefinition(){const e=this._lexer.token;return this.expectKeyword("fragment"),this._options.allowLegacyFragmentVariables===!0?this.node(e,{kind:c.FRAGMENT_DEFINITION,name:this.parseFragmentName(),variableDefinitions:this.parseVariableDefinitions(),typeCondition:(this.expectKeyword("on"),this.parseNamedType()),directives:this.parseDirectives(!1),selectionSet:this.parseSelectionSet()}):this.node(e,{kind:c.FRAGMENT_DEFINITION,name:this.parseFragmentName(),typeCondition:(this.expectKeyword("on"),this.parseNamedType()),directives:this.parseDirectives(!1),selectionSet:this.parseSelectionSet()})}parseFragmentName(){if(this._lexer.token.value==="on")throw this.unexpected();return this.parseName()}parseValueLiteral(e){const t=this._lexer.token;switch(t.kind){case a.BRACKET_L:return this.parseList(e);case a.BRACE_L:return this.parseObject(e);case a.INT:return this.advanceLexer(),this.node(t,{kind:c.INT,value:t.value});case a.FLOAT:return this.advanceLexer(),this.node(t,{kind:c.FLOAT,value:t.value});case a.STRING:case a.BLOCK_STRING:return this.parseStringLiteral();case a.NAME:switch(this.advanceLexer(),t.value){case"true":return this.node(t,{kind:c.BOOLEAN,value:!0});case"false":return this.node(t,{kind:c.BOOLEAN,value:!1});case"null":return this.node(t,{kind:c.NULL});default:return this.node(t,{kind:c.ENUM,value:t.value})}case a.DOLLAR:if(e)if(this.expectToken(a.DOLLAR),this._lexer.token.kind===a.NAME){const r=this._lexer.token.value;throw m(this._lexer.source,t.start,`Unexpected variable "$${r}" in constant value.`)}else throw this.unexpected(t);return this.parseVariable();default:throw this.unexpected()}}parseConstValueLiteral(){return this.parseValueLiteral(!0)}parseStringLiteral(){const e=this._lexer.token;return this.advanceLexer(),this.node(e,{kind:c.STRING,value:e.value,block:e.kind===a.BLOCK_STRING})}parseList(e){const t=()=>this.parseValueLiteral(e);return this.node(this._lexer.token,{kind:c.LIST,values:this.any(a.BRACKET_L,t,a.BRACKET_R)})}parseObject(e){const t=()=>this.parseObjectField(e);return this.node(this._lexer.token,{kind:c.OBJECT,fields:this.any(a.BRACE_L,t,a.BRACE_R)})}parseObjectField(e){const t=this._lexer.token,r=this.parseName();return this.expectToken(a.COLON),this.node(t,{kind:c.OBJECT_FIELD,name:r,value:this.parseValueLiteral(e)})}parseDirectives(e){const t=[];for(;this.peek(a.AT);)t.push(this.parseDirective(e));return t}parseConstDirectives(){return this.parseDirectives(!0)}parseDirective(e){const t=this._lexer.token;return this.expectToken(a.AT),this.node(t,{kind:c.DIRECTIVE,name:this.parseName(),arguments:this.parseArguments(e)})}parseTypeReference(){const e=this._lexer.token;let t;if(this.expectOptionalToken(a.BRACKET_L)){const r=this.parseTypeReference();this.expectToken(a.BRACKET_R),t=this.node(e,{kind:c.LIST_TYPE,type:r})}else t=this.parseNamedType();return this.expectOptionalToken(a.BANG)?this.node(e,{kind:c.NON_NULL_TYPE,type:t}):t}parseNamedType(){return this.node(this._lexer.token,{kind:c.NAMED_TYPE,name:this.parseName()})}peekDescription(){return this.peek(a.STRING)||this.peek(a.BLOCK_STRING)}parseDescription(){if(this.peekDescription())return this.parseStringLiteral()}parseSchemaDefinition(){const e=this._lexer.token,t=this.parseDescription();this.expectKeyword("schema");const r=this.parseConstDirectives(),s=this.many(a.BRACE_L,this.parseOperationTypeDefinition,a.BRACE_R);return this.node(e,{kind:c.SCHEMA_DEFINITION,description:t,directives:r,operationTypes:s})}parseOperationTypeDefinition(){const e=this._lexer.token,t=this.parseOperationType();this.expectToken(a.COLON);const r=this.parseNamedType();return this.node(e,{kind:c.OPERATION_TYPE_DEFINITION,operation:t,type:r})}parseScalarTypeDefinition(){const e=this._lexer.token,t=this.parseDescription();this.expectKeyword("scalar");const r=this.parseName(),s=this.parseConstDirectives();return this.node(e,{kind:c.SCALAR_TYPE_DEFINITION,description:t,name:r,directives:s})}parseObjectTypeDefinition(){const e=this._lexer.token,t=this.parseDescription();this.expectKeyword("type");const r=this.parseName(),s=this.parseImplementsInterfaces(),i=this.parseConstDirectives(),o=this.parseFieldsDefinition();return this.node(e,{kind:c.OBJECT_TYPE_DEFINITION,description:t,name:r,interfaces:s,directives:i,fields:o})}parseImplementsInterfaces(){return this.expectOptionalKeyword("implements")?this.delimitedMany(a.AMP,this.parseNamedType):[]}parseFieldsDefinition(){return this.optionalMany(a.BRACE_L,this.parseFieldDefinition,a.BRACE_R)}parseFieldDefinition(){const e=this._lexer.token,t=this.parseDescription(),r=this.parseName(),s=this.parseArgumentDefs();this.expectToken(a.COLON);const i=this.parseTypeReference(),o=this.parseConstDirectives();return this.node(e,{kind:c.FIELD_DEFINITION,description:t,name:r,arguments:s,type:i,directives:o})}parseArgumentDefs(){return this.optionalMany(a.PAREN_L,this.parseInputValueDef,a.PAREN_R)}parseInputValueDef(){const e=this._lexer.token,t=this.parseDescription(),r=this.parseName();this.expectToken(a.COLON);const s=this.parseTypeReference();let i;this.expectOptionalToken(a.EQUALS)&&(i=this.parseConstValueLiteral());const o=this.parseConstDirectives();return this.node(e,{kind:c.INPUT_VALUE_DEFINITION,description:t,name:r,type:s,defaultValue:i,directives:o})}parseInterfaceTypeDefinition(){const e=this._lexer.token,t=this.parseDescription();this.expectKeyword("interface");const r=this.parseName(),s=this.parseImplementsInterfaces(),i=this.parseConstDirectives(),o=this.parseFieldsDefinition();return this.node(e,{kind:c.INTERFACE_TYPE_DEFINITION,description:t,name:r,interfaces:s,directives:i,fields:o})}parseUnionTypeDefinition(){const e=this._lexer.token,t=this.parseDescription();this.expectKeyword("union");const r=this.parseName(),s=this.parseConstDirectives(),i=this.parseUnionMemberTypes();return this.node(e,{kind:c.UNION_TYPE_DEFINITION,description:t,name:r,directives:s,types:i})}parseUnionMemberTypes(){return this.expectOptionalToken(a.EQUALS)?this.delimitedMany(a.PIPE,this.parseNamedType):[]}parseEnumTypeDefinition(){const e=this._lexer.token,t=this.parseDescription();this.expectKeyword("enum");const r=this.parseName(),s=this.parseConstDirectives(),i=this.parseEnumValuesDefinition();return this.node(e,{kind:c.ENUM_TYPE_DEFINITION,description:t,name:r,directives:s,values:i})}parseEnumValuesDefinition(){return this.optionalMany(a.BRACE_L,this.parseEnumValueDefinition,a.BRACE_R)}parseEnumValueDefinition(){const e=this._lexer.token,t=this.parseDescription(),r=this.parseEnumValueName(),s=this.parseConstDirectives();return this.node(e,{kind:c.ENUM_VALUE_DEFINITION,description:t,name:r,directives:s})}parseEnumValueName(){if(this._lexer.token.value==="true"||this._lexer.token.value==="false"||this._lexer.token.value==="null")throw m(this._lexer.source,this._lexer.token.start,`${D(this._lexer.token)} is reserved and cannot be used for an enum value.`);return this.parseName()}parseInputObjectTypeDefinition(){const e=this._lexer.token,t=this.parseDescription();this.expectKeyword("input");const r=this.parseName(),s=this.parseConstDirectives(),i=this.parseInputFieldsDefinition();return this.node(e,{kind:c.INPUT_OBJECT_TYPE_DEFINITION,description:t,name:r,directives:s,fields:i})}parseInputFieldsDefinition(){return this.optionalMany(a.BRACE_L,this.parseInputValueDef,a.BRACE_R)}parseTypeSystemExtension(){const e=this._lexer.lookahead();if(e.kind===a.NAME)switch(e.value){case"schema":return this.parseSchemaExtension();case"scalar":return this.parseScalarTypeExtension();case"type":return this.parseObjectTypeExtension();case"interface":return this.parseInterfaceTypeExtension();case"union":return this.parseUnionTypeExtension();case"enum":return this.parseEnumTypeExtension();case"input":return this.parseInputObjectTypeExtension()}throw this.unexpected(e)}parseSchemaExtension(){const e=this._lexer.token;this.expectKeyword("extend"),this.expectKeyword("schema");const t=this.parseConstDirectives(),r=this.optionalMany(a.BRACE_L,this.parseOperationTypeDefinition,a.BRACE_R);if(t.length===0&&r.length===0)throw this.unexpected();return this.node(e,{kind:c.SCHEMA_EXTENSION,directives:t,operationTypes:r})}parseScalarTypeExtension(){const e=this._lexer.token;this.expectKeyword("extend"),this.expectKeyword("scalar");const t=this.parseName(),r=this.parseConstDirectives();if(r.length===0)throw this.unexpected();return this.node(e,{kind:c.SCALAR_TYPE_EXTENSION,name:t,directives:r})}parseObjectTypeExtension(){const e=this._lexer.token;this.expectKeyword("extend"),this.expectKeyword("type");const t=this.parseName(),r=this.parseImplementsInterfaces(),s=this.parseConstDirectives(),i=this.parseFieldsDefinition();if(r.length===0&&s.length===0&&i.length===0)throw this.unexpected();return this.node(e,{kind:c.OBJECT_TYPE_EXTENSION,name:t,interfaces:r,directives:s,fields:i})}parseInterfaceTypeExtension(){const e=this._lexer.token;this.expectKeyword("extend"),this.expectKeyword("interface");const t=this.parseName(),r=this.parseImplementsInterfaces(),s=this.parseConstDirectives(),i=this.parseFieldsDefinition();if(r.length===0&&s.length===0&&i.length===0)throw this.unexpected();return this.node(e,{kind:c.INTERFACE_TYPE_EXTENSION,name:t,interfaces:r,directives:s,fields:i})}parseUnionTypeExtension(){const e=this._lexer.token;this.expectKeyword("extend"),this.expectKeyword("union");const t=this.parseName(),r=this.parseConstDirectives(),s=this.parseUnionMemberTypes();if(r.length===0&&s.length===0)throw this.unexpected();return this.node(e,{kind:c.UNION_TYPE_EXTENSION,name:t,directives:r,types:s})}parseEnumTypeExtension(){const e=this._lexer.token;this.expectKeyword("extend"),this.expectKeyword("enum");const t=this.parseName(),r=this.parseConstDirectives(),s=this.parseEnumValuesDefinition();if(r.length===0&&s.length===0)throw this.unexpected();return this.node(e,{kind:c.ENUM_TYPE_EXTENSION,name:t,directives:r,values:s})}parseInputObjectTypeExtension(){const e=this._lexer.token;this.expectKeyword("extend"),this.expectKeyword("input");const t=this.parseName(),r=this.parseConstDirectives(),s=this.parseInputFieldsDefinition();if(r.length===0&&s.length===0)throw this.unexpected();return this.node(e,{kind:c.INPUT_OBJECT_TYPE_EXTENSION,name:t,directives:r,fields:s})}parseDirectiveDefinition(){const e=this._lexer.token,t=this.parseDescription();this.expectKeyword("directive"),this.expectToken(a.AT);const r=this.parseName(),s=this.parseArgumentDefs(),i=this.expectOptionalKeyword("repeatable");this.expectKeyword("on");const o=this.parseDirectiveLocations();return this.node(e,{kind:c.DIRECTIVE_DEFINITION,description:t,name:r,arguments:s,repeatable:i,locations:o})}parseDirectiveLocations(){return this.delimitedMany(a.PIPE,this.parseDirectiveLocation)}parseDirectiveLocation(){const e=this._lexer.token,t=this.parseName();if(Object.prototype.hasOwnProperty.call(G,t.value))return t;throw this.unexpected(e)}node(e,t){return this._options.noLocation!==!0&&(t.loc=new Ne(e,this._lexer.lastToken,this._lexer.source)),t}peek(e){return this._lexer.token.kind===e}expectToken(e){const t=this._lexer.token;if(t.kind===e)return this.advanceLexer(),t;throw m(this._lexer.source,t.start,`Expected ${pe(e)}, found ${D(t)}.`)}expectOptionalToken(e){return this._lexer.token.kind===e?(this.advanceLexer(),!0):!1}expectKeyword(e){const t=this._lexer.token;if(t.kind===a.NAME&&t.value===e)this.advanceLexer();else throw m(this._lexer.source,t.start,`Expected "${e}", found ${D(t)}.`)}expectOptionalKeyword(e){const t=this._lexer.token;return t.kind===a.NAME&&t.value===e?(this.advanceLexer(),!0):!1}unexpected(e){const t=e??this._lexer.token;return m(this._lexer.source,t.start,`Unexpected ${D(t)}.`)}any(e,t,r){this.expectToken(e);const s=[];for(;!this.expectOptionalToken(r);)s.push(t.call(this));return s}optionalMany(e,t,r){if(this.expectOptionalToken(e)){const s=[];do s.push(t.call(this));while(!this.expectOptionalToken(r));return s}return[]}many(e,t,r){this.expectToken(e);const s=[];do s.push(t.call(this));while(!this.expectOptionalToken(r));return s}delimitedMany(e,t){this.expectOptionalToken(e);const r=[];do r.push(t.call(this));while(this.expectOptionalToken(e));return r}advanceLexer(){const{maxTokens:e}=this._options,t=this._lexer.advance();if(t.kind!==a.EOF&&(++this._tokenCounter,e!==void 0&&this._tokenCounter>e))throw m(this._lexer.source,t.start,`Document contains more that ${e} tokens. Parsing aborted.`)}}function D(n){const e=n.value;return pe(n.kind)+(e!=null?` "${e}"`:"")}function pe(n){return Fe(n)?`"${n}"`:n}var Je=(function(n){_(e,n);function e(t,r){return n.call(this)||this}return e.prototype.schedule=function(t,r){return this},e})(Te),W={setInterval:function(n,e){for(var t=[],r=2;r<arguments.length;r++)t[r-2]=arguments[r];return setInterval.apply(void 0,te([n,e],ne(t)))},clearInterval:function(n){return clearInterval(n)},delegate:void 0},We=(function(n){_(e,n);function e(t,r){var s=n.call(this,t,r)||this;return s.scheduler=t,s.work=r,s.pending=!1,s}return e.prototype.schedule=function(t,r){var s;if(r===void 0&&(r=0),this.closed)return this;this.state=t;var i=this.id,o=this.scheduler;return i!=null&&(this.id=this.recycleAsyncId(o,i,r)),this.pending=!0,this.delay=r,this.id=(s=this.id)!==null&&s!==void 0?s:this.requestAsyncId(o,this.id,r),this},e.prototype.requestAsyncId=function(t,r,s){return s===void 0&&(s=0),W.setInterval(t.flush.bind(t,this),s)},e.prototype.recycleAsyncId=function(t,r,s){if(s===void 0&&(s=0),s!=null&&this.delay===s&&this.pending===!1)return r;r!=null&&W.clearInterval(r)},e.prototype.execute=function(t,r){if(this.closed)return new Error("executing a cancelled action");this.pending=!1;var s=this._execute(t,r);if(s)return s;this.pending===!1&&this.id!=null&&(this.id=this.recycleAsyncId(this.scheduler,this.id,null))},e.prototype._execute=function(t,r){var s=!1,i;try{this.work(t)}catch(o){s=!0,i=o||new Error("Scheduled action threw falsy error")}if(s)return this.unsubscribe(),i},e.prototype.unsubscribe=function(){if(!this.closed){var t=this,r=t.id,s=t.scheduler,i=s.actions;this.work=this.state=this.scheduler=null,this.pending=!1,ge(i,this),r!=null&&(this.id=this.recycleAsyncId(s,r,null)),this.delay=null,n.prototype.unsubscribe.call(this)}},e})(Je),Xe=1,B,K={};function X(n){return n in K?(delete K[n],!0):!1}var fe={setImmediate:function(n){var e=Xe++;return K[e]=!0,B||(B=Promise.resolve()),B.then(function(){return X(e)&&n()}),e},clearImmediate:function(n){X(n)}},Ze=fe.setImmediate,et=fe.clearImmediate,Z={setImmediate:function(){for(var n=[],e=0;e<arguments.length;e++)n[e]=arguments[e];return Ze.apply(void 0,te([],ne(n)))},clearImmediate:function(n){return et(n)},delegate:void 0},tt=(function(n){_(e,n);function e(t,r){var s=n.call(this,t,r)||this;return s.scheduler=t,s.work=r,s}return e.prototype.requestAsyncId=function(t,r,s){return s===void 0&&(s=0),s!==null&&s>0?n.prototype.requestAsyncId.call(this,t,r,s):(t.actions.push(this),t._scheduled||(t._scheduled=Z.setImmediate(t.flush.bind(t,void 0))))},e.prototype.recycleAsyncId=function(t,r,s){var i;if(s===void 0&&(s=0),s!=null?s>0:this.delay>0)return n.prototype.recycleAsyncId.call(this,t,r,s);var o=t.actions;r!=null&&((i=o[o.length-1])===null||i===void 0?void 0:i.id)!==r&&(Z.clearImmediate(r),t._scheduled===r&&(t._scheduled=void 0))},e})(We),ee=(function(){function n(e,t){t===void 0&&(t=n.now),this.schedulerActionCtor=e,this.now=t}return n.prototype.schedule=function(e,t,r){return t===void 0&&(t=0),new this.schedulerActionCtor(this,e).schedule(r,t)},n.now=Ae.now,n})(),nt=(function(n){_(e,n);function e(t,r){r===void 0&&(r=ee.now);var s=n.call(this,t,r)||this;return s.actions=[],s._active=!1,s}return e.prototype.flush=function(t){var r=this.actions;if(this._active){r.push(t);return}var s;this._active=!0;do if(s=t.execute(t.state,t.delay))break;while(t=r.shift());if(this._active=!1,s){for(;t=r.shift();)t.unsubscribe();throw s}},e})(ee),st=(function(n){_(e,n);function e(){return n!==null&&n.apply(this,arguments)||this}return e.prototype.flush=function(t){this._active=!0;var r=this._scheduled;this._scheduled=void 0;var s=this.actions,i;t=t||s.shift();do if(i=t.execute(t.state,t.delay))break;while((t=s[0])&&t.id===r&&s.shift());if(this._active=!1,i){for(;(t=s[0])&&t.id===r&&s.shift();)t.unsubscribe();throw i}},e})(nt),rt=new st(tt);const it=typeof q(()=>window.document.createElement)=="function";var L=new Map,j=new Map,me=!0,F=!1;function ye(n){return n.replace(/[\s,]+/g," ").trim()}function at(n){return ye(n.source.body.substring(n.start,n.end))}function ot(n){var e=new Set,t=[];return n.definitions.forEach(function(r){if(r.kind==="FragmentDefinition"){var s=r.name.value,i=at(r.loc),o=j.get(s);o&&!o.has(i)?me&&console.warn("Warning: fragment with name "+s+` already exists.
graphql-tag enforces all fragment names across your application to be unique; read more about
this in the docs: http://dev.apollodata.com/core/fragments.html#unique-names`):o||j.set(s,o=new Set),o.add(i),e.has(i)||(e.add(i),t.push(r))}else t.push(r)}),Q(Q({},n),{definitions:t})}function ct(n){var e=new Set(n.definitions);e.forEach(function(r){r.loc&&delete r.loc,Object.keys(r).forEach(function(s){var i=r[s];i&&typeof i=="object"&&e.add(i)})});var t=n.loc;return t&&(delete t.startToken,delete t.endToken),n}function ut(n){var e=ye(n);if(!L.has(e)){var t=ze(n,{experimentalFragmentVariables:F,allowLegacyFragmentVariables:F});if(!t||t.kind!=="Document")throw new Error("Not a valid GraphQL document.");L.set(e,ct(ot(t)))}return L.get(e)}function p(n){for(var e=[],t=1;t<arguments.length;t++)e[t-1]=arguments[t];typeof n=="string"&&(n=[n]);var r=n[0];return e.forEach(function(s,i){s&&s.kind==="Document"?r+=s.loc.source.body:r+=s,r+=n[i+1]}),ut(r)}function lt(){L.clear(),j.clear()}function dt(){me=!1}function ht(){F=!0}function pt(){F=!1}var C={gql:p,resetCaches:lt,disableFragmentWarnings:dt,enableExperimentalFragmentVariables:ht,disableExperimentalFragmentVariables:pt};(function(n){n.gql=C.gql,n.resetCaches=C.resetCaches,n.disableFragmentWarnings=C.disableFragmentWarnings,n.enableExperimentalFragmentVariables=C.enableExperimentalFragmentVariables,n.disableExperimentalFragmentVariables=C.disableExperimentalFragmentVariables})(p||(p={}));p.default=p;const ft=Symbol.for("apollo.hook.wrappers");function mt(n,e,t){const r=[t.queryManager,n.startsWith("use")?N.useContext(se()):void 0];let s=e;for(const i of r){const o=i?.[ft]?.[n];o&&(s=o(s))}return s}const yt="useSyncExternalStore",Et=_e[yt],vt=q(()=>navigator.product)=="ReactNative",xt=q(()=>navigator.userAgent.indexOf("jsdom")>=0)||!1,Nt=(it||vt)&&!xt,Tt=Et||((n,e,t)=>{const r=e(),[{inst:s},i]=N.useState({inst:{value:r,getSnapshot:e}});return Nt?N.useLayoutEffect(()=>{Object.assign(s,{value:r,getSnapshot:e}),$(s)&&i({inst:s})},[n,r,e]):Object.assign(s,{value:r,getSnapshot:e}),N.useEffect(()=>($(s)&&i({inst:s}),n(function(){$(s)&&i({inst:s})})),[n]),r});function $({value:n,getSnapshot:e}){try{return n!==e()}catch{return!0}}const w=Symbol();function O(n,...[e]){"use no memo";return mt("useQuery",gt,ce(e&&e.client))(n,e)}function gt(n,e={}){const t=ce(e.client),{skip:r,ssr:s,...i}=e,o=Ie(t.defaultOptions.watchQuery,{...i,query:n});r&&(o.initialFetchPolicy=e.initialFetchPolicy||e.fetchPolicy,o.fetchPolicy="standby");function l(x){const k=t.watchQuery(o);return{client:t,query:n,observable:k,resultData:{current:k.getCurrentResult(),previousData:x?.resultData.current.data,variables:k.variables}}}let[d,y]=N.useState(l);(t!==d.client||n!==d.query)&&y(d=l(d));const{observable:u,resultData:v}=d;At(o,u),kt(v,u,o);const E=It(u,v,e.ssr),g=N.useMemo(()=>({refetch:u.refetch.bind(u),fetchMore:u.fetchMore.bind(u),updateQuery:u.updateQuery.bind(u),startPolling:u.startPolling.bind(u),stopPolling:u.stopPolling.bind(u),subscribeToMore:u.subscribeToMore.bind(u)}),[u]),f=v.previousData;return N.useMemo(()=>{const{partial:x,...k}=E;return{...k,client:t,observable:u,variables:u.variables,previousData:f,...g}},[E,t,u,f,g])}function At(n,e){"use no memo";n.fetchPolicy||(n.fetchPolicy=e.options.initialFetchPolicy)}function It(n,e,t){"use no memo";return Tt(N.useCallback(r=>{const s=n.pipe(ke(rt)).subscribe(i=>{const o=e.current;A(o,i)&&A(e.variables,n.variables)||(e.variables=n.variables,o.data&&!A(o.data,i.data)&&(e.previousData=o.data),e.current=i,r())});return()=>{setTimeout(()=>s.unsubscribe())}},[n,e]),()=>e.current,()=>t===!1?O.ssrDisabledResult:e.current)}function kt(n,e,t){"use no memo";if(e[w]&&!A(e[w],t)){Ct(e[w],t)?e.reobserve(t):e.applyOptions(t);const r=e.getCurrentResult();A(r.data,n.current.data)||(n.previousData=n.current.data||n.previousData),n.current=r,n.variables=e.variables}e[w]=t}function Ct(n,e){return n.query!==e.query||!A(n.variables,e.variables)||n.fetchPolicy!==e.fetchPolicy&&(e.fetchPolicy==="standby"||n.fetchPolicy==="standby")}O.ssrDisabledResult=Ce({loading:!0,data:void 0,dataState:"empty",error:void 0,networkStatus:be.loading,partial:!0});p`
  mutation Login($email: String!, $password: String!) {
    login(email: $email, password: $password) {
      user {
        id
        email
        name
        role
        dealerName
        dealerLogoUrl
        dealerAddress
        dealerCity
        dealerPhoneNumber
        savedListingIds
      }
      access_token
    }
  }
`;p`
  mutation Register($email: String!, $password: String!, $name: String, $role: UserRole = USER) {
    register(email: $email, password: $password, name: $name, role: $role) {
      user {
        id
        email
        name
        role
        dealerName
        dealerLogoUrl
        dealerAddress
        dealerCity
        dealerPhoneNumber
        savedListingIds
      }
      access_token
    }
  }
`;p`
  query Me {
    me {
      id
      email
      name
      role
      dealerName
      dealerLogoUrl
      dealerAddress
      dealerCity
      dealerPhoneNumber
      savedListingIds
    }
  }
`;const bt=p`
  query GetCars($filters: FilterCarsInput) {
    cars(filters: $filters) {
      id
      carMake {
        id
        name
      }
      carModel {
        id
        name
      }
      year
      price
      currency
      mileage
      fuelType
      transmissionType
      bodyType
      exteriorColor
      description
      imageUrls
      location
      status
      features
      user {
        id
        name
        email
        dealerName
        dealerLogoUrl
        dealerPhoneNumber
      }
      createdAt
      updatedAt
    }
  }
`,_t=p`
  query GetCarById($id: ID!) {
    car(id: $id) {
      id
      carMake {
        id
        name
      }
      carModel {
        id
        name
      }
      year
      price
      currency
      mileage
      fuelType
      transmissionType
      bodyType
      exteriorColor
      description
      imageUrls
      location
      status
      features
      engineSize
      powerKw
      numberOfDoors
      numberOfSeats
      previousOwners
      fullServiceHistory
      user {
        id
        name
        email
        dealerName
        dealerLogoUrl
        dealerPhoneNumber
      }
      createdAt
      updatedAt
    }
  }
`;p`
  query GetFeaturedCars {
    findCarsForYou {
      id
      carMake {
        id
        name
      }
      carModel {
        id
        name
      }
      year
      price
      currency
      mileage
      fuelType
      transmissionType
      bodyType
      exteriorColor
      description
      imageUrls
      location
      status
      features
      user {
        id
        name
        email
        dealerName
        dealerLogoUrl
      }
      createdAt
      updatedAt
    }
  }
`;p`
  query GetCarsByMake($makeId: ID!) {
    cars(filters: { makeId: $makeId }) {
      id
      carMake {
        id
        name
      }
      carModel {
        id
        name
      }
      year
      price
      currency
      mileage
      fuelType
      transmissionType
      bodyType
      exteriorColor
      description
      imageUrls
      location
      status
      features
      user {
        id
        name
        email
        dealerName
      }
      createdAt
      updatedAt
    }
  }
`;const Ot=p`
  query GetCarMakes {
    carMakes {
      id
      name
      carModels {
        id
        name
      }
    }
  }
`;p`
  query GetCarModelsByMake($carMakeId: ID!) {
    carModelsByMake(carMakeId: $carMakeId) {
      id
      name
      carMake {
        id
        name
      }
    }
  }
`;p`
  query SearchCars($filters: FilterCarsInput) {
    cars(filters: $filters) {
      id
      carMake {
        id
        name
      }
      carModel {
        id
        name
      }
      year
      price
      currency
      mileage
      fuelType
      transmissionType
      bodyType
      exteriorColor
      description
      imageUrls
      location
      status
      features
      user {
        id
        name
        email
        dealerName
        dealerLogoUrl
        dealerPhoneNumber
      }
      createdAt
      updatedAt
    }
  }
`;p`
  mutation CreateCar($createCarInput: CreateCarInput!) {
    createCar(createCarInput: $createCarInput) {
      id
      carMake {
        id
        name
      }
      carModel {
        id
        name
      }
      year
      price
      currency
      mileage
      fuelType
      transmissionType
      bodyType
      exteriorColor
      description
      imageUrls
      location
      status
      features
      engineSize
      powerKw
      numberOfDoors
      numberOfSeats
      previousOwners
      fullServiceHistory
      user {
        id
        name
        email
      }
      createdAt
    }
  }
`;p`
  mutation UpdateCar($updateCarInput: UpdateCarInput!) {
    updateCar(updateCarInput: $updateCarInput) {
      id
      carMake {
        id
        name
      }
      carModel {
        id
        name
      }
      year
      price
      currency
      mileage
      fuelType
      transmissionType
      bodyType
      exteriorColor
      description
      imageUrls
      location
      status
      features
      engineSize
      powerKw
      numberOfDoors
      numberOfSeats
      previousOwners
      fullServiceHistory
      user {
        id
        name
        email
      }
      updatedAt
    }
  }
`;p`
  mutation RemoveCar($id: ID!) {
    removeCar(id: $id)
  }
`;p`
  query GetUsers {
    users {
      id
      email
      name
      role
      dealerName
      dealerLogoUrl
      dealerAddress
      dealerCity
      dealerPhoneNumber
      savedListingIds
      createdAt
    }
  }
`;function Lt(n){const{country:e}=oe(),t={...n,...e&&e.code!=="global"?{location:e.name}:{}},{data:r,loading:s,error:i,refetch:o}=O(bt,{variables:{filters:t},errorPolicy:"all",notifyOnNetworkStatusChange:!0,fetchPolicy:"cache-and-network"});return{cars:r?.cars||[],isLoading:s,error:i?.message||null,refetch:async()=>{await o()}}}function Rt(n){const{country:e}=oe(),{data:t,loading:r,error:s,refetch:i}=O(_t,{variables:{id:n},skip:!n,errorPolicy:"all",notifyOnNetworkStatusChange:!0,fetchPolicy:"cache-and-network"}),o=t?.car||null;let l=s?.message||null;return o&&e&&e.code!=="global"&&o.location&&!o.location.toLowerCase().includes(e.name.toLowerCase())&&(console.warn(`🚫 Car ${n} is not available in ${e.code} (location: ${o.location})`),l="This car listing is not available in your region"),{car:l==="This car listing is not available in your region"?null:o,isLoading:r,error:l,refetch:async()=>{await i()}}}function Ft(){const{data:n,loading:e,error:t}=O(Ot,{errorPolicy:"all",fetchPolicy:"cache-first"});return{makes:n?.carMakes||[],isLoading:e,error:t?.message||null}}export{Ft as a,Rt as b,Lt as u};
