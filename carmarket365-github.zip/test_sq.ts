import { TranslationStrings } from "../translations"; import { sqTranslations } from "./sq"; export const test: TranslationStrings = sqTranslations;
